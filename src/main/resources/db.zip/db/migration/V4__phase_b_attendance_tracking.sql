-- =====================================================
-- PHASE B: ATTENDANCE & DUTY TRACKING ENGINE
-- Migration: V4__phase_b_attendance_tracking.sql
-- Description: Complete attendance tracking system with check-in/out, auto-status detection
-- Author: SGMS Development Team
-- Date: 2026-02-18
-- =====================================================

-- =====================================================
-- STEP 1: CREATE ENUM TYPES
-- =====================================================

-- Attendance status enum
CREATE TYPE attendance_status AS ENUM (
    'PRESENT',           -- Guard checked in and out on time
    'LATE',              -- Guard checked in after shift start time
    'EARLY_LEAVE',       -- Guard checked out before shift end time
    'ABSENT',            -- Guard never checked in (auto-marked by scheduler)
    'MISSED_CHECKOUT'    -- Guard checked in but never checked out (auto-marked)
);

-- =====================================================
-- STEP 2: CREATE ATTENDANCE LOGS TABLE
-- =====================================================

CREATE TABLE attendance_logs (
    -- Primary key
    id BIGSERIAL PRIMARY KEY,
    
    -- Foreign Keys
    guard_id BIGINT NOT NULL,
    assignment_id BIGINT NOT NULL,
    
    -- Attendance tracking
    attendance_date DATE NOT NULL,
    check_in_time TIMESTAMP,
    check_out_time TIMESTAMP,
    
    -- Status and metrics
    status attendance_status NOT NULL DEFAULT 'PRESENT',
    late_minutes INTEGER DEFAULT 0,
    early_leave_minutes INTEGER DEFAULT 0,
    
    -- Additional info
    notes TEXT,
    
    -- Audit fields
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    CONSTRAINT fk_attendance_guard FOREIGN KEY (guard_id) 
        REFERENCES guards(id) ON DELETE RESTRICT,
    CONSTRAINT fk_attendance_assignment FOREIGN KEY (assignment_id) 
        REFERENCES guard_assignments(id) ON DELETE RESTRICT,
    
    -- Business rules constraints
    CONSTRAINT chk_checkout_after_checkin 
        CHECK (check_out_time IS NULL OR check_out_time >= check_in_time),
    CONSTRAINT chk_late_minutes_positive 
        CHECK (late_minutes >= 0),
    CONSTRAINT chk_early_leave_minutes_positive 
        CHECK (early_leave_minutes >= 0),
    
    -- Unique constraint: one attendance record per guard per date
    CONSTRAINT uk_guard_date UNIQUE (guard_id, attendance_date)
);

-- =====================================================
-- STEP 3: CREATE INDEXES FOR PERFORMANCE
-- =====================================================

-- Index for guard-based queries
CREATE INDEX idx_attendance_guard_id ON attendance_logs(guard_id);

-- Index for assignment-based queries
CREATE INDEX idx_attendance_assignment_id ON attendance_logs(assignment_id);

-- Index for date-based queries
CREATE INDEX idx_attendance_date ON attendance_logs(attendance_date);

-- Index for status-based queries (scheduled jobs)
CREATE INDEX idx_attendance_status ON attendance_logs(status);

-- Composite index for guard + date range queries
CREATE INDEX idx_attendance_guard_date_range ON attendance_logs(guard_id, attendance_date);

-- Composite index for finding pending checkouts (scheduler optimization)
CREATE INDEX idx_attendance_pending_checkout 
    ON attendance_logs(attendance_date, status) 
    WHERE check_in_time IS NOT NULL AND check_out_time IS NULL;

-- Index for site-based queries (joining through assignment)
CREATE INDEX idx_attendance_site_date 
    ON attendance_logs(assignment_id, attendance_date);

-- =====================================================
-- STEP 4: CREATE HELPER VIEWS
-- =====================================================

-- View: Today's attendance summary with guard and site details
CREATE OR REPLACE VIEW v_today_attendance_summary AS
SELECT 
    al.id AS attendance_id,
    al.attendance_date,
    al.check_in_time,
    al.check_out_time,
    al.status,
    al.late_minutes,
    al.early_leave_minutes,
    
    -- Guard info
    g.id AS guard_id,
    g.first_name AS guard_first_name,
    g.last_name AS guard_last_name,
    g.employee_number,
    
    -- Assignment info
    ga.id AS assignment_id,
    
    -- Site post info
    sp.id AS site_post_id,
    sp.post_name,
    
    -- Site info
    s.id AS site_id,
    s.site_name,
    
    -- Client info
    c.id AS client_id,
    c.company_name AS client_name,
    
    -- Shift info
    st.name AS shift_name,
    st.start_time AS shift_start,
    st.end_time AS shift_end
    
FROM attendance_logs al
INNER JOIN guards g ON al.guard_id = g.id
INNER JOIN guard_assignments ga ON al.assignment_id = ga.id
INNER JOIN site_posts sp ON ga.site_post_id = sp.id
INNER JOIN sites s ON sp.site_id = s.id
INNER JOIN clients c ON s.client_id = c.id
INNER JOIN shift_types st ON ga.shift_type_id = st.id

WHERE al.attendance_date = CURRENT_DATE
  AND g.deleted_at IS NULL
  AND s.deleted_at IS NULL
  AND c.deleted_at IS NULL;

-- View: Active guards who haven't checked in today
CREATE OR REPLACE VIEW v_pending_checkins_today AS
SELECT 
    ga.id AS assignment_id,
    g.id AS guard_id,
    g.first_name,
    g.last_name,
    g.employee_number,
    sp.post_name,
    s.site_name,
    c.company_name,
    st.name AS shift_name,
    st.start_time AS shift_start,
    st.end_time AS shift_end
    
FROM guard_assignments ga
INNER JOIN guards g ON ga.guard_id = g.id
INNER JOIN site_posts sp ON ga.site_post_id = sp.id
INNER JOIN sites s ON sp.site_id = s.id
INNER JOIN clients c ON s.client_id = c.id
INNER JOIN shift_types st ON ga.shift_type_id = st.id

WHERE ga.status = 'ACTIVE'
  AND (ga.effective_from <= CURRENT_DATE)
  AND (ga.effective_to IS NULL OR ga.effective_to >= CURRENT_DATE)
  AND g.status = 'ACTIVE'
  AND g.deleted_at IS NULL
  AND s.deleted_at IS NULL
  AND c.deleted_at IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM attendance_logs al 
      WHERE al.guard_id = g.id 
        AND al.attendance_date = CURRENT_DATE
  );

-- View: Guards who checked in but haven't checked out
CREATE OR REPLACE VIEW v_pending_checkouts_today AS
SELECT 
    al.id AS attendance_id,
    al.guard_id,
    g.first_name,
    g.last_name,
    g.employee_number,
    al.check_in_time,
    sp.post_name,
    s.site_name,
    st.name AS shift_name,
    st.end_time AS shift_end
    
FROM attendance_logs al
INNER JOIN guards g ON al.guard_id = g.id
INNER JOIN guard_assignments ga ON al.assignment_id = ga.id
INNER JOIN site_posts sp ON ga.site_post_id = sp.id
INNER JOIN sites s ON sp.site_id = s.id
INNER JOIN shift_types st ON ga.shift_type_id = st.id

WHERE al.attendance_date = CURRENT_DATE
  AND al.check_in_time IS NOT NULL
  AND al.check_out_time IS NULL
  AND g.deleted_at IS NULL;

-- =====================================================
-- STEP 5: CREATE UPDATE TRIGGER FOR TIMESTAMP
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_attendance_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger on attendance_logs table
CREATE TRIGGER trg_update_attendance_timestamp
BEFORE UPDATE ON attendance_logs
FOR EACH ROW
EXECUTE FUNCTION update_attendance_timestamp();

-- =====================================================
-- STEP 6: ADD HELPFUL COMMENTS
-- =====================================================

COMMENT ON TABLE attendance_logs IS 'Core attendance tracking table with check-in/out times and auto-calculated status';
COMMENT ON COLUMN attendance_logs.status IS 'Auto-calculated: PRESENT, LATE, EARLY_LEAVE, ABSENT, MISSED_CHECKOUT';
COMMENT ON COLUMN attendance_logs.late_minutes IS 'Calculated: minutes between shift start and actual check-in (if late)';
COMMENT ON COLUMN attendance_logs.early_leave_minutes IS 'Calculated: minutes between actual check-out and shift end (if early)';
COMMENT ON CONSTRAINT uk_guard_date ON attendance_logs IS 'Business rule: one attendance record per guard per day';

COMMENT ON VIEW v_today_attendance_summary IS 'Denormalized view of all attendance records for current date with full details';
COMMENT ON VIEW v_pending_checkins_today IS 'Guards with active assignments who have not checked in today (used by absent marker job)';
COMMENT ON VIEW v_pending_checkouts_today IS 'Guards who checked in but have not checked out yet (used by missed checkout job)';

-- =====================================================
-- END OF MIGRATION V4
-- =====================================================
