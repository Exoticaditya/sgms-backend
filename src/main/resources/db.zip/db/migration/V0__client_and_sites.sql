-- =====================================================
-- PHASE 0: Client and Site Foundation
-- Migration Script V0
-- =====================================================
-- Description:
--   Creates foundational tables for client account management
--   and site location tracking. These tables are prerequisites
--   for site_posts, supervisor_site_mapping, and client_site_access.
--
-- Tables Created:
--   1. client_accounts - Client company records
--   2. sites - Physical locations managed by SGMS
--
-- Prerequisites:
--   - PostgreSQL database with pgcrypto extension
--   - No dependencies (runs first)
--
-- Execution Order:
--   This MUST run BEFORE:
--   - V1 (needs these for guard/supervisor context)
--   - V2 (site_posts references sites)
--   - V3 (views join these tables)
--
-- Date: 2026-02-18
-- =====================================================

SET search_path TO public;

-- =====================================================
-- 1. CLIENT_ACCOUNTS TABLE
-- =====================================================
-- Represents client companies that use SGMS services

CREATE TABLE IF NOT EXISTS client_accounts (
  id BIGSERIAL PRIMARY KEY,
  
  -- Client information
  name VARCHAR(255) NOT NULL,
  contact_person VARCHAR(255),
  contact_email VARCHAR(255),
  contact_phone VARCHAR(30),
  address TEXT,
  
  -- Business fields
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  contract_start_date DATE,
  contract_end_date DATE,
  
  -- Audit fields
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  
  -- Constraints
  CONSTRAINT chk_client_status 
    CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'TERMINATED'))
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_client_accounts_status 
  ON client_accounts(status);

CREATE INDEX IF NOT EXISTS idx_client_accounts_deleted_at 
  ON client_accounts(deleted_at);

CREATE INDEX IF NOT EXISTS idx_client_accounts_name 
  ON client_accounts(name);

-- Trigger function for updating updated_at
CREATE OR REPLACE FUNCTION update_client_accounts_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger on client_accounts
CREATE TRIGGER trg_update_client_accounts_timestamp
BEFORE UPDATE ON client_accounts
FOR EACH ROW
EXECUTE FUNCTION update_client_accounts_timestamp();

-- Comments
COMMENT ON TABLE client_accounts IS 'Client companies using SGMS security services';
COMMENT ON COLUMN client_accounts.status IS 'ACTIVE, INACTIVE, SUSPENDED, TERMINATED';
COMMENT ON COLUMN client_accounts.deleted_at IS 'Soft delete timestamp (NULL = active)';

-- =====================================================
-- 2. SITES TABLE
-- =====================================================
-- Represents physical locations/sites managed by SGMS

CREATE TABLE IF NOT EXISTS sites (
  id BIGSERIAL PRIMARY KEY,
  
  -- Foreign key to client
  client_account_id BIGINT NOT NULL,
  
  -- Site information
  name VARCHAR(255) NOT NULL,
  address VARCHAR(500),
  city VARCHAR(100),
  state VARCHAR(50),
  zip_code VARCHAR(20),
  country VARCHAR(100) DEFAULT 'USA',
  
  -- Geographic coordinates for mobile check-in validation
  latitude NUMERIC(10, 8),
  longitude NUMERIC(11, 8),
  geofence_radius_meters INTEGER DEFAULT 100,
  
  -- Site configuration
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  site_manager_name VARCHAR(255),
  site_manager_phone VARCHAR(30),
  site_manager_email VARCHAR(255),
  
  -- Operating hours (optional, for shift validation)
  operating_hours TEXT,
  
  -- Audit fields
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  
  -- Foreign key constraints
  CONSTRAINT fk_sites_client_account 
    FOREIGN KEY (client_account_id) 
    REFERENCES client_accounts(id) 
    ON DELETE RESTRICT,
    
  -- Business constraints
  CONSTRAINT chk_site_status 
    CHECK (status IN ('ACTIVE', 'INACTIVE', 'CLOSED', 'SUSPENDED')),
    
  CONSTRAINT chk_latitude_range 
    CHECK (latitude IS NULL OR (latitude >= -90 AND latitude <= 90)),
    
  CONSTRAINT chk_longitude_range 
    CHECK (longitude IS NULL OR (longitude >= -180 AND longitude <= 180)),
    
  CONSTRAINT chk_geofence_radius_positive 
    CHECK (geofence_radius_meters > 0)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_sites_client_account_id 
  ON sites(client_account_id);

CREATE INDEX IF NOT EXISTS idx_sites_status 
  ON sites(status);

CREATE INDEX IF NOT EXISTS idx_sites_deleted_at 
  ON sites(deleted_at);

CREATE INDEX IF NOT EXISTS idx_sites_name 
  ON sites(name);

-- Composite index for active sites by client
CREATE INDEX IF NOT EXISTS idx_sites_client_active 
  ON sites(client_account_id, status) 
  WHERE deleted_at IS NULL;

-- Geospatial index for location-based queries (if needed in future)
CREATE INDEX IF NOT EXISTS idx_sites_location 
  ON sites(latitude, longitude) 
  WHERE latitude IS NOT NULL AND longitude IS NOT NULL;

-- Trigger function for updating updated_at
CREATE OR REPLACE FUNCTION update_sites_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger on sites
CREATE TRIGGER trg_update_sites_timestamp
BEFORE UPDATE ON sites
FOR EACH ROW
EXECUTE FUNCTION update_sites_timestamp();

-- Comments
COMMENT ON TABLE sites IS 'Physical locations/sites managed by SGMS';
COMMENT ON COLUMN sites.client_account_id IS 'Foreign key to client_accounts table';
COMMENT ON COLUMN sites.latitude IS 'Latitude for geofencing (optional)';
COMMENT ON COLUMN sites.longitude IS 'Longitude for geofencing (optional)';
COMMENT ON COLUMN sites.geofence_radius_meters IS 'Radius in meters for mobile check-in validation';
COMMENT ON COLUMN sites.status IS 'ACTIVE, INACTIVE, CLOSED, SUSPENDED';
COMMENT ON COLUMN sites.deleted_at IS 'Soft delete timestamp (NULL = active)';

-- =====================================================
-- SEED DATA: Sample Client Account
-- =====================================================
-- Insert a default client for initial testing

INSERT INTO client_accounts (
  name, 
  contact_person, 
  contact_email, 
  contact_phone,
  status,
  contract_start_date
)
VALUES (
  'Demo Corporation',
  'John Doe',
  'john.doe@democorp.com',
  '+1-555-0100',
  'ACTIVE',
  CURRENT_DATE
)
ON CONFLICT DO NOTHING;

-- Insert a sample site for the demo client
INSERT INTO sites (
  client_account_id,
  name,
  address,
  city,
  state,
  zip_code,
  latitude,
  longitude,
  geofence_radius_meters,
  status,
  site_manager_name,
  site_manager_phone
)
SELECT 
  ca.id,
  'Demo Corporate Headquarters',
  '123 Business Street',
  'New York',
  'NY',
  '10001',
  40.7128,
  -74.0060,
  150,
  'ACTIVE',
  'Jane Smith',
  '+1-555-0200'
FROM client_accounts ca
WHERE ca.name = 'Demo Corporation'
LIMIT 1
ON CONFLICT DO NOTHING;

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Verify tables created
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('client_accounts', 'sites')
ORDER BY table_name;

-- Verify foreign key constraint
SELECT
  conname AS constraint_name,
  conrelid::regclass AS table_name,
  confrelid::regclass AS referenced_table
FROM pg_constraint
WHERE conname = 'fk_sites_client_account';

-- Verify seed data
SELECT 
  'client_accounts' AS table_name, 
  COUNT(*) AS record_count 
FROM client_accounts
UNION ALL
SELECT 
  'sites' AS table_name, 
  COUNT(*) AS record_count 
FROM sites;

-- Show sample data
SELECT 
  ca.id AS client_id,
  ca.name AS client_name,
  ca.status AS client_status,
  COUNT(s.id) AS site_count
FROM client_accounts ca
LEFT JOIN sites s ON ca.client_account_id = s.id AND s.deleted_at IS NULL
WHERE ca.deleted_at IS NULL
GROUP BY ca.id, ca.name, ca.status
ORDER BY ca.name;

-- =====================================================
-- HELPER VIEWS
-- =====================================================

-- View: Active sites with client details
CREATE OR REPLACE VIEW v_active_sites AS
SELECT 
  s.id AS site_id,
  s.name AS site_name,
  s.address,
  s.city,
  s.state,
  s.status AS site_status,
  ca.id AS client_id,
  ca.name AS client_name,
  ca.status AS client_status,
  s.latitude,
  s.longitude,
  s.geofence_radius_meters,
  s.site_manager_name,
  s.site_manager_phone,
  s.created_at
FROM sites s
INNER JOIN client_accounts ca ON s.client_account_id = ca.id
WHERE s.deleted_at IS NULL
  AND ca.deleted_at IS NULL
  AND s.status = 'ACTIVE'
ORDER BY ca.name, s.name;

COMMENT ON VIEW v_active_sites IS 'Active sites with client information denormalized';

-- =====================================================
-- END OF MIGRATION V0
-- =====================================================
