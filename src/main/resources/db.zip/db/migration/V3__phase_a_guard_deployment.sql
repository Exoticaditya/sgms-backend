-- =====================================================
-- PHASE A: Guard Deployment (Operations Core)
-- Migration Script V3
-- =====================================================
-- Description:
--   Creates tables for guard deployment operations including
--   shift type management and guard-to-post assignments.
--
-- Tables Created:
--   1. shift_types - Shift definitions (DAY, NIGHT, EVENING)
--   2. guard_assignments - Guard deployment to site posts
--
-- Prerequisites:
--   - guards table must exist (PHASE 1)
--   - site_posts table must exist (PHASE 3)
--   - users table must exist (PHASE 1)
--
-- Execution:
--   Run this on Railway PostgreSQL BEFORE deploying code
-- =====================================================

SET search_path TO public;

-- =====================================================
-- 1. SHIFT_TYPES TABLE
-- =====================================================
-- Lookup table for shift types with timing information

CREATE TABLE IF NOT EXISTS shift_types (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Business validation: name must be uppercase
  CONSTRAINT chk_shift_type_name_uppercase 
    CHECK (name = UPPER(name))
);

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_shift_types_name 
  ON shift_types(name);

COMMENT ON TABLE shift_types IS 'Shift type definitions (DAY, NIGHT, EVENING)';
COMMENT ON COLUMN shift_types.name IS 'Shift type name (e.g., DAY, NIGHT, EVENING) - uppercase';
COMMENT ON COLUMN shift_types.start_time IS 'Shift start time';
COMMENT ON COLUMN shift_types.end_time IS 'Shift end time';

-- =====================================================
-- 2. GUARD_ASSIGNMENTS TABLE
-- =====================================================
-- Maps guards to site posts with shift and date range

CREATE TABLE IF NOT EXISTS guard_assignments (
  id BIGSERIAL PRIMARY KEY,
  guard_id BIGINT NOT NULL,
  site_post_id BIGINT NOT NULL,
  shift_type_id BIGINT NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by_user_id BIGINT NOT NULL,
  
  -- Foreign key constraints
  CONSTRAINT fk_guard_assignments_guard 
    FOREIGN KEY (guard_id) 
    REFERENCES guards(id) 
    ON DELETE RESTRICT,
    
  CONSTRAINT fk_guard_assignments_site_post 
    FOREIGN KEY (site_post_id) 
    REFERENCES site_posts(id) 
    ON DELETE RESTRICT,
    
  CONSTRAINT fk_guard_assignments_shift_type 
    FOREIGN KEY (shift_type_id) 
    REFERENCES shift_types(id) 
    ON DELETE RESTRICT,
    
  CONSTRAINT fk_guard_assignments_created_by 
    FOREIGN KEY (created_by_user_id) 
    REFERENCES users(id) 
    ON DELETE RESTRICT,
    
  -- Business validation: effective_to must be after effective_from
  CONSTRAINT chk_effective_dates_order 
    CHECK (effective_to IS NULL OR effective_to >= effective_from),
    
  -- Status validation
  CONSTRAINT chk_assignment_status 
    CHECK (status IN ('ACTIVE', 'INACTIVE', 'COMPLETED', 'CANCELLED'))
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_guard_assignments_guard_id 
  ON guard_assignments(guard_id);

CREATE INDEX IF NOT EXISTS idx_guard_assignments_site_post_id 
  ON guard_assignments(site_post_id);

CREATE INDEX IF NOT EXISTS idx_guard_assignments_shift_type_id 
  ON guard_assignments(shift_type_id);

CREATE INDEX IF NOT EXISTS idx_guard_assignments_status 
  ON guard_assignments(status);

CREATE INDEX IF NOT EXISTS idx_guard_assignments_effective_from 
  ON guard_assignments(effective_from);

CREATE INDEX IF NOT EXISTS idx_guard_assignments_effective_to 
  ON guard_assignments(effective_to);

-- Composite index for active assignment queries
CREATE INDEX IF NOT EXISTS idx_guard_assignments_active_lookup 
  ON guard_assignments(guard_id, status, effective_from, effective_to);

-- Composite index for site post assignment queries
CREATE INDEX IF NOT EXISTS idx_guard_assignments_post_active 
  ON guard_assignments(site_post_id, status, effective_from, effective_to);

COMMENT ON TABLE guard_assignments IS 'Guard deployment assignments to site posts';
COMMENT ON COLUMN guard_assignments.guard_id IS 'Foreign key to guards table';
COMMENT ON COLUMN guard_assignments.site_post_id IS 'Foreign key to site_posts table';
COMMENT ON COLUMN guard_assignments.shift_type_id IS 'Foreign key to shift_types table';
COMMENT ON COLUMN guard_assignments.effective_from IS 'Assignment start date';
COMMENT ON COLUMN guard_assignments.effective_to IS 'Assignment end date (NULL = ongoing)';
COMMENT ON COLUMN guard_assignments.status IS 'ACTIVE, INACTIVE, COMPLETED, CANCELLED';
COMMENT ON COLUMN guard_assignments.notes IS 'Optional notes about the assignment';
COMMENT ON COLUMN guard_assignments.created_by_user_id IS 'User who created this assignment (supervisor/admin)';

-- =====================================================
-- SEED DATA: SHIFT TYPES
-- =====================================================
-- Insert standard shift types

INSERT INTO shift_types (name, start_time, end_time, description)
VALUES 
  ('DAY', '06:00:00', '14:00:00', 'Day shift - morning to afternoon'),
  ('EVENING', '14:00:00', '22:00:00', 'Evening shift - afternoon to night'),
  ('NIGHT', '22:00:00', '06:00:00', 'Night shift - night to morning')
ON CONFLICT (name) DO NOTHING;

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Check all tables created
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('shift_types', 'guard_assignments')
ORDER BY table_name;

-- Verify foreign key constraints
SELECT
  conname AS constraint_name,
  conrelid::regclass AS table_name,
  confrelid::regclass AS referenced_table
FROM pg_constraint
WHERE conname IN (
  'fk_guard_assignments_guard',
  'fk_guard_assignments_site_post',
  'fk_guard_assignments_shift_type',
  'fk_guard_assignments_created_by'
)
ORDER BY conname;

-- Verify shift types seeded
SELECT id, name, start_time, end_time, description
FROM shift_types
ORDER BY start_time;

-- Count records
SELECT 
  'shift_types' AS table_name, 
  COUNT(*) AS record_count 
FROM shift_types
UNION ALL
SELECT 
  'guard_assignments' AS table_name, 
  COUNT(*) AS record_count 
FROM guard_assignments;

-- =====================================================
-- HELPER VIEWS (OPTIONAL)
-- =====================================================

-- View for active guard assignments with details
CREATE OR REPLACE VIEW v_active_guard_assignments AS
SELECT 
  ga.id AS assignment_id,
  ga.guard_id,
  g.employee_code,
  g.first_name || ' ' || COALESCE(g.last_name, '') AS guard_name,
  ga.site_post_id,
  sp.post_name,
  s.name AS site_name,
  ca.name AS client_name,
  ga.shift_type_id,
  st.name AS shift_type,
  st.start_time,
  st.end_time,
  ga.effective_from,
  ga.effective_to,
  ga.status,
  ga.notes,
  ga.created_at,
  u.email AS created_by_email
FROM guard_assignments ga
  JOIN guards g ON ga.guard_id = g.id
  JOIN site_posts sp ON ga.site_post_id = sp.id
  JOIN sites s ON sp.site_id = s.id
  JOIN client_accounts ca ON s.client_account_id = ca.id
  JOIN shift_types st ON ga.shift_type_id = st.id
  JOIN users u ON ga.created_by_user_id = u.id
WHERE ga.status = 'ACTIVE'
  AND g.deleted_at IS NULL
  AND sp.deleted_at IS NULL
  AND s.deleted_at IS NULL
ORDER BY ga.effective_from DESC, ga.created_at DESC;

COMMENT ON VIEW v_active_guard_assignments IS 'Active guard assignments with denormalized details';

-- =====================================================
-- USEFUL QUERIES FOR OPERATIONS
-- =====================================================

-- Query: Get current active assignments for a guard
-- SELECT * FROM v_active_guard_assignments WHERE guard_id = ?;

-- Query: Get all guards assigned to a site post
-- SELECT * FROM v_active_guard_assignments WHERE site_post_id = ?;

-- Query: Find guards without active assignments
-- SELECT g.id, g.employee_code, g.first_name, g.last_name, g.status
-- FROM guards g
-- WHERE g.deleted_at IS NULL 
--   AND g.status = 'ACTIVE'
--   AND NOT EXISTS (
--     SELECT 1 FROM guard_assignments ga 
--     WHERE ga.guard_id = g.id 
--       AND ga.status = 'ACTIVE'
--       AND ga.effective_from <= CURRENT_DATE
--       AND (ga.effective_to IS NULL OR ga.effective_to >= CURRENT_DATE)
--   );

-- Query: Get site posts needing more guards
-- SELECT 
--   sp.id,
--   sp.post_name,
--   s.name AS site_name,
--   sp.required_guards,
--   COUNT(ga.id) AS assigned_guards,
--   (sp.required_guards - COUNT(ga.id)) AS deficit
-- FROM site_posts sp
--   JOIN sites s ON sp.site_id = s.id
--   LEFT JOIN guard_assignments ga ON sp.id = ga.site_post_id 
--     AND ga.status = 'ACTIVE'
--     AND ga.effective_from <= CURRENT_DATE
--     AND (ga.effective_to IS NULL OR ga.effective_to >= CURRENT_DATE)
-- WHERE sp.deleted_at IS NULL
--   AND s.deleted_at IS NULL
-- GROUP BY sp.id, sp.post_name, s.name, sp.required_guards
-- HAVING COUNT(ga.id) < sp.required_guards
-- ORDER BY deficit DESC;

-- =====================================================
-- END OF MIGRATION
-- =====================================================
